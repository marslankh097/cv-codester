package com.amit018.cv_application;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class education extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_education);
    }
}